const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
const port = 3000;

// Enable Cross-Origin Resource Sharing (CORS)
app.use(cors());

// Parse incoming JSON data
app.use(bodyParser.json());
app.use(express.static('public')); // Serve static files from 'public' folder

// POST route to handle form data submission
app.post('/submit', (req, res) => {
  const { name, email, phone } = req.body;

  if (!name || !email || !phone) {
    return res.status(400).json({ error: "Missing data" });
  }

  // Save to database or file (example using console.log here)
  console.log("Received Data: ", { name, email, phone });

  // Respond with success message
  res.json({ message: "Data saved successfully!" });
});

// Start server
app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
