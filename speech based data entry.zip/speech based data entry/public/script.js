const fields = ['name', 'email', 'phone'];
let currentField = 0;

const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
recognition.lang = 'en-US';
recognition.interimResults = false;

function startRecognition(fieldId) {
  recognition.start();

  recognition.onresult = function(event) {
    const transcript = event.results[0][0].transcript;
    document.getElementById(fieldId).value = transcript;
  };

  recognition.onerror = function(event) {
    alert("Error occurred: " + event.error);
  };
}

function submitData() {
  const name = document.getElementById('name').value;
  const email = document.getElementById('email').value;
  const phone = document.getElementById('phone').value;

  if (!name || !email || !phone) {
    alert("Please fill in all fields before submitting.");
    return;
  }

  const data = { name, email, phone };

  fetch('/submit', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  })
  .then(response => response.json())
  .then(data => alert('Data submitted successfully!'))
  .catch(error => alert('Error submitting data: ' + error));
}
